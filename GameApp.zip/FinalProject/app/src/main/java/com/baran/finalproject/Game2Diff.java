package com.baran.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Game2Diff extends AppCompatActivity {

    int Game2saniye=20000;
    int zorluk=1000;

    public void setTimer20(View view){
        Game2saniye=20000;
    }
    public void setTimer25(View view){
        Game2saniye=25000;
    }
    public void setTimer30(View view){
        Game2saniye=30000;
    }

    public void setdiffEASY(View view){
        zorluk = 750;
    }
    public void setdiffMED(View view){
        zorluk = 500;
    }
    public void setdiffHARD(View view){
        zorluk = 250;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2_diff);
    }
    public void startGame2(View view){
        Intent intent= new Intent(Game2Diff.this,Game2.class);
        intent.putExtra("Game2Saniye",Game2saniye);
        intent.putExtra("Game2zorluk",zorluk);
        startActivity(intent);
    }

    public void backtomenu(View view){
        Intent intent= new Intent(Game2Diff.this,MainActivity.class);
        startActivity(intent);
    }
}