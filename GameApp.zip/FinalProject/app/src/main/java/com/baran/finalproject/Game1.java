package com.baran.finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class Game1 extends AppCompatActivity {

    int saniye=10000;
    int zorluk=500;
    TextView timer;
    TextView score;
    int gameScore;
    ImageView po1;
    ImageView po2;
    ImageView po3;
    ImageView po4;
    ImageView po5;
    ImageView po6;
    ImageView po7;
    ImageView po8;
    ImageView po9;
    ImageView[] images;

    Handler handler;
    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game1);

        Intent intent=getIntent();
        saniye=intent.getIntExtra("Saniye",10000);
        zorluk=intent.getIntExtra("Zorluk",500);

        timer = (TextView)findViewById(R.id.timer);
        score = (TextView)findViewById(R.id.score);
        gameScore=0;

        po1=findViewById(R.id.Po);
        po2=findViewById(R.id.Po2);
        po3=findViewById(R.id.Po3);
        po4=findViewById(R.id.Po4);
        po5=findViewById(R.id.Po5);
        po6=findViewById(R.id.Po6);
        po7=findViewById(R.id.Po7);
        po8=findViewById(R.id.Po8);
        po9=findViewById(R.id.Po9);


        // 10 saniyeden başlayan ve 1 er saniye azalan sayaç için gerekli değerler
        new CountDownTimer(saniye,1000){

            @Override
            public void onTick(long l) {
                double second= l/1000;
                timer.setText("TimeLeft: "+second);
            }

            @Override
            public void onFinish() {
                handler.removeCallbacks(runnable);

                //sayaç bitince bütün resimleri ortadan kaldırmak için
                for (ImageView image: images){
                    image.setVisibility(View.INVISIBLE);
                }

                AlertDialog.Builder alert= new AlertDialog.Builder(Game1.this);
                alert.setTitle("Game Over");
                alert.setMessage("Your Score : "+gameScore+". Would you like to play again?");
                alert.setCancelable(false);

                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //oyunu tekrar başlat
                        Intent intent = getIntent();
                        finish();
                        startActivity(intent);
                    }
                });

                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();//oyunu kapat hayır seçilirse -> System.exit(0);
                    }
                });
                alert.show();
            }
        }.start();

        images= new ImageView[]{po1,po2,po3,po4,po5,po6,po7,po8,po9};
        hideimages();
    }

    public void increaseScore(View view){
        gameScore++;
        score.setText("Score : "+gameScore);
    }

    //görselleri görünmez yap
    private void hideimages() {

        handler= new Handler();
        runnable = new Runnable() {
            @Override
            public void run() {
                for (ImageView image: images){
                    image.setVisibility(View.INVISIBLE);
                }
                Random randomnumber= new Random();
                int sayı= randomnumber.nextInt(9);
                images[sayı].setVisibility(View.VISIBLE);// 9 random fotoğraftan sadece 1ini visible yapmak için

                handler.postDelayed(runnable,zorluk); // zorluk ayarı -> zorluk=250 saniye başı 4 photo, zorluk=500 saniye başı 2 photo, zorluk=100 saniye başı 1 photo,
            }
        };
        handler.post(runnable);
    }

}