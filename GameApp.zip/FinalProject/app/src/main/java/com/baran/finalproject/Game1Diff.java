package com.baran.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Game1Diff extends AppCompatActivity {

    int saniye=10000;
    int zorluk=500;

    public void setTimer10(View view){
        saniye=10000;
    }
    public void setTimer15(View view){
        saniye=15000;
    }
    public void setTimer20(View view){
        saniye=20000;
    }



    public void setdiffEASY(View view){
        zorluk = 1000;
    }
    public void setdiffMED(View view){
        zorluk = 500;
    }
    public void setdiffHARD(View view){
        zorluk = 250;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game1_diff);
    }
    public void startClickingGame(View view){
        Intent intent= new Intent(Game1Diff.this,Game1.class);
        intent.putExtra("Saniye",saniye);
        intent.putExtra("Zorluk",zorluk);
        startActivity(intent);
    }

    public void backtomenu(View view){
        Intent intent= new Intent(Game1Diff.this,MainActivity.class);
        startActivity(intent);
    }

}