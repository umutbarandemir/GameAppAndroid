package com.baran.finalproject;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Collections;

public class Game2 extends AppCompatActivity {

    int Game2saniye=30000;
    int game2zorluk;
    TextView Game2Timer;
    ImageView card1,card2,card3,card4,card5,card6,card7,card8,card9,card10,card11,card12,card13,card14,card15,card16;

    CountDownTimer gameTIMER=null;

    Integer[] Cards = {101,102,103,104,105,106,107,108,201,202,203,204,205,206,207,208};

    int photo101,photo102,photo103,photo104,photo105,photo106,photo107,photo108,photo201,photo202,photo203,photo204,photo205,photo206,photo207,photo208;

    int firstcard, secondcard;
    int click1,click2;
    int cardNumber=1;

    Handler handler;
    Runnable runnable;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2);
        Intent intent=getIntent();
        Game2saniye=intent.getIntExtra("Game2Saniye",20000);
        game2zorluk=intent.getIntExtra("Game2zorluk",750);

        Game2Timer = (TextView)findViewById(R.id.Game2Timer);

        card1=findViewById(R.id.Card1);
        card2=findViewById(R.id.Card2);
        card3=findViewById(R.id.Card3);
        card4=findViewById(R.id.Card4);
        card5=findViewById(R.id.Card5);
        card6=findViewById(R.id.Card6);
        card7=findViewById(R.id.Card7);
        card8=findViewById(R.id.Card8);
        card9=findViewById(R.id.Card9);
        card10=findViewById(R.id.Card10);
        card11=findViewById(R.id.Card11);
        card12=findViewById(R.id.Card12);
        card13=findViewById(R.id.Card13);
        card14=findViewById(R.id.Card14);
        card15=findViewById(R.id.Card15);
        card16=findViewById(R.id.Card16);

        card1.setTag("0");
        card2.setTag("1");
        card3.setTag("2");
        card4.setTag("3");
        card5.setTag("4");
        card6.setTag("5");
        card7.setTag("6");
        card8.setTag("7");
        card9.setTag("8");
        card10.setTag("9");
        card11.setTag("10");
        card12.setTag("11");
        card13.setTag("12");
        card14.setTag("13");
        card15.setTag("14");
        card16.setTag("15");

        putimagesoncards();
        startTimer();

        // Shuffleing cards
        Collections.shuffle(Arrays.asList(Cards));

        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card1,theCard);
            }
        });

        card2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card2,theCard);
            }
        });

        card3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card3,theCard);
            }
        });

        card4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card4,theCard);
            }
        });

        card5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card5,theCard);
            }
        });

        card6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card6,theCard);
            }
        });

        card7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card7,theCard);
            }
        });

        card8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card8,theCard);
            }
        });

        card9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card9,theCard);
            }
        });

        card10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card10,theCard);
            }
        });

        card11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card11,theCard);
            }
        });

        card12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card12,theCard);
            }
        });

        card13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card13,theCard);
            }
        });

        card14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card14,theCard);
            }
        });

        card15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card15,theCard);
            }
        });

        card16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theCard= Integer.parseInt((String)view.getTag());
                gameplay(card16,theCard);
            }
        });

    }

    private void putimagesoncards() {
        photo101=R.drawable.kaplan;
        photo102=R.drawable.leylek;
        photo103=R.drawable.mantis;
        photo104=R.drawable.monkey;
        photo105=R.drawable.oogway;
        photo106=R.drawable.pogame2;
        photo107=R.drawable.shifu;
        photo108=R.drawable.yilan;

        photo201=R.drawable.kaplan;
        photo202=R.drawable.leylek;
        photo203=R.drawable.mantis;
        photo204=R.drawable.monkey;
        photo205=R.drawable.oogway;
        photo206=R.drawable.pogame2;
        photo207=R.drawable.shifu;
        photo208=R.drawable.yilan;

    }

    void startTimer() {
        // Sayaç
        gameTIMER=new CountDownTimer(Game2saniye, 1000) {

            @Override
            public void onTick(long l) {
                double second = l / 1000;
                Game2Timer.setText("TimeLeft: " + second);
            }

            @Override
            public void onFinish() {

                AlertDialog.Builder alert = new AlertDialog.Builder(Game2.this);
                alert.setTitle("Time is Over");
                alert.setMessage("Would you like to play again?");
                alert.setCancelable(false);
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //oyunu tekrar başlat
                        Intent timerintent = new Intent(getApplicationContext(), Game2.class);
                        finish();
                        startActivity(timerintent);
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();//oyunu kapat hayır seçilirse
                    }
                });
                alert.show();
            }
        };
        gameTIMER.start();
    }

    void cancelTimer(){
        if (gameTIMER!=null){
            gameTIMER.cancel();
        }
    }


    private void gameplay(ImageView card, int theCard) {
        if (Cards[theCard]==101){
            card.setImageResource(photo101);
        }else if (Cards[theCard]==102){
            card.setImageResource(photo102);
        }else if (Cards[theCard]==103){
            card.setImageResource(photo103);
        }else if (Cards[theCard]==104){
            card.setImageResource(photo104);
        }else if (Cards[theCard]==105){
            card.setImageResource(photo105);
        }else if (Cards[theCard]==106){
            card.setImageResource(photo106);
        }else if (Cards[theCard]==107){
            card.setImageResource(photo107);
        }else if (Cards[theCard]==108){
            card.setImageResource(photo108);
        }else if (Cards[theCard]==201){
            card.setImageResource(photo201);
        }else if (Cards[theCard]==202){
            card.setImageResource(photo202);
        }else if (Cards[theCard]==203){
            card.setImageResource(photo203);
        }else if (Cards[theCard]==204){
            card.setImageResource(photo204);
        }else if (Cards[theCard]==205){
            card.setImageResource(photo205);
        }else if (Cards[theCard]==206){
            card.setImageResource(photo206);
        }else if (Cards[theCard]==207){
            card.setImageResource(photo207);
        }else if (Cards[theCard]==208){
            card.setImageResource(photo208);
        }

        if (cardNumber==1){
            firstcard=Cards[theCard];
            if (firstcard>=201){
                firstcard=firstcard-100;
            }
            cardNumber=2;
            click1=theCard;
            card.setEnabled(false);

        }else if (cardNumber==2){
            secondcard=Cards[theCard];
            if (secondcard>=201){
                secondcard=secondcard-100;
            }
            cardNumber=1;
            click2=theCard;

            card1.setEnabled(false);
            card2.setEnabled(false);
            card3.setEnabled(false);
            card4.setEnabled(false);
            card5.setEnabled(false);
            card6.setEnabled(false);
            card7.setEnabled(false);
            card8.setEnabled(false);
            card9.setEnabled(false);
            card10.setEnabled(false);
            card11.setEnabled(false);
            card12.setEnabled(false);
            card13.setEnabled(false);
            card14.setEnabled(false);
            card15.setEnabled(false);
            card16.setEnabled(false);

            Handler handler=new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    compare();
                }
            },game2zorluk);

        }
    }
    //fotoğraflar aynıysa doğru çift görünmez yapılacak
    private void compare() {
        if (firstcard==secondcard){
            if (click1==0){
                card1.setVisibility(View.INVISIBLE);
            }else if (click1==1){
                card2.setVisibility(View.INVISIBLE);
            } else if (click1==2){
                card3.setVisibility(View.INVISIBLE);
            } else if (click1==3){
                card4.setVisibility(View.INVISIBLE);
            } else if (click1==4){
                card5.setVisibility(View.INVISIBLE);
            } else if (click1==5){
                card6.setVisibility(View.INVISIBLE);
            } else if (click1==6){
                card7.setVisibility(View.INVISIBLE);
            } else if (click1==7){
                card8.setVisibility(View.INVISIBLE);
            } else if (click1==8){
                card9.setVisibility(View.INVISIBLE);
            } else if (click1==9){
                card10.setVisibility(View.INVISIBLE);
            } else if (click1==10){
                card11.setVisibility(View.INVISIBLE);
            } else if (click1==11){
                card12.setVisibility(View.INVISIBLE);
            } else if (click1==12){
                card13.setVisibility(View.INVISIBLE);
            } else if (click1==13){
                card14.setVisibility(View.INVISIBLE);
            } else if (click1==14){
                card15.setVisibility(View.INVISIBLE);
            } else if (click1==15){
                card16.setVisibility(View.INVISIBLE);
            }


            if (click2==0){
                card1.setVisibility(View.INVISIBLE);
            }else if (click2==1){
                card2.setVisibility(View.INVISIBLE);
            } else if (click2==2){
                card3.setVisibility(View.INVISIBLE);
            } else if (click2==3){
                card4.setVisibility(View.INVISIBLE);
            } else if (click2==4){
                card5.setVisibility(View.INVISIBLE);
            } else if (click2==5){
                card6.setVisibility(View.INVISIBLE);
            } else if (click2==6){
                card7.setVisibility(View.INVISIBLE);
            } else if (click2==7){
                card8.setVisibility(View.INVISIBLE);
            } else if (click2==8){
                card9.setVisibility(View.INVISIBLE);
            } else if (click2==9){
                card10.setVisibility(View.INVISIBLE);
            } else if (click2==10){
                card11.setVisibility(View.INVISIBLE);
            } else if (click2==11){
                card12.setVisibility(View.INVISIBLE);
            } else if (click2==12){
                card13.setVisibility(View.INVISIBLE);
            } else if (click2==13){
                card14.setVisibility(View.INVISIBLE);
            } else if (click2==14){
                card15.setVisibility(View.INVISIBLE);
            } else if (click2==15){
                card16.setVisibility(View.INVISIBLE);
            }

        //if it doen't match. flip back the card
        }else{
            card1.setImageResource(R.drawable.cardback);
            card2.setImageResource(R.drawable.cardback);
            card3.setImageResource(R.drawable.cardback);
            card4.setImageResource(R.drawable.cardback);
            card5.setImageResource(R.drawable.cardback);
            card6.setImageResource(R.drawable.cardback);
            card7.setImageResource(R.drawable.cardback);
            card8.setImageResource(R.drawable.cardback);
            card9.setImageResource(R.drawable.cardback);
            card10.setImageResource(R.drawable.cardback);
            card11.setImageResource(R.drawable.cardback);
            card12.setImageResource(R.drawable.cardback);
            card13.setImageResource(R.drawable.cardback);
            card14.setImageResource(R.drawable.cardback);
            card15.setImageResource(R.drawable.cardback);
            card16.setImageResource(R.drawable.cardback);

        }

        card1.setEnabled(true);
        card2.setEnabled(true);
        card3.setEnabled(true);
        card4.setEnabled(true);
        card5.setEnabled(true);
        card6.setEnabled(true);
        card7.setEnabled(true);
        card8.setEnabled(true);
        card9.setEnabled(true);
        card10.setEnabled(true);
        card11.setEnabled(true);
        card12.setEnabled(true);
        card13.setEnabled(true);
        card14.setEnabled(true);
        card15.setEnabled(true);
        card16.setEnabled(true);
        
        isover();
    }

    private void isover() {
        if (card1.getVisibility()==View.INVISIBLE&&card2.getVisibility()==View.INVISIBLE&&card3.getVisibility()==View.INVISIBLE&&card4.getVisibility()==View.INVISIBLE&&card5.getVisibility()==View.INVISIBLE&&card6.getVisibility()==View.INVISIBLE&&card7.getVisibility()==View.INVISIBLE&&card8.getVisibility()==View.INVISIBLE&&card9.getVisibility()==View.INVISIBLE&&card10.getVisibility()==View.INVISIBLE&&card11.getVisibility()==View.INVISIBLE&&card12.getVisibility()==View.INVISIBLE&&card13.getVisibility()==View.INVISIBLE&&card14.getVisibility()==View.INVISIBLE&&card15.getVisibility()==View.INVISIBLE&&card16.getVisibility()==View.INVISIBLE){
            AlertDialog.Builder gameoverAlert=new AlertDialog.Builder(Game2.this);
            cancelTimer();
            gameoverAlert.setTitle("Game Over");
            gameoverAlert.setMessage(" Would you like to play again?");
            gameoverAlert.setCancelable(false);
            gameoverAlert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent=new Intent(getApplicationContext(),Game2.class);
                    finish();
                    startActivity(intent);
                }
            }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
        AlertDialog alertDialog= gameoverAlert.create();
        alertDialog.show();
        }
    }




}